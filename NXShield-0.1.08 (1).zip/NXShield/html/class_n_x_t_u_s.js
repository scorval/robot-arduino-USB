var class_n_x_t_u_s =
[
    [ "NXTUS", "class_n_x_t_u_s.html#a51b4f742f7f477749419ab8267404d59", null ],
    [ "getDeviceID", "class_n_x_t_u_s.html#a01858dc9bdb88f0de262226abf82bc56", null ],
    [ "getDist", "class_n_x_t_u_s.html#a263fb6e714483b54092c53dcc895f84a", null ],
    [ "getFirmwareVersion", "class_n_x_t_u_s.html#ac0599523be28bdd01ef79bae80e34a48", null ],
    [ "getVendorID", "class_n_x_t_u_s.html#a55f627f08efa405a87391c26467be30e", null ],
    [ "init", "class_n_x_t_u_s.html#a9822cd21c93950f69dbdd8ff78fccbcf", null ]
];