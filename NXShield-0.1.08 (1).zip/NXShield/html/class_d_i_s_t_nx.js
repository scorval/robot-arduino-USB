var class_d_i_s_t_nx =
[
    [ "DISTNx", "class_d_i_s_t_nx.html#a293b6ddbca28dec4c641066cd6ad3559", null ],
    [ "deEnergize", "class_d_i_s_t_nx.html#a60418ec9478c00833710949c7203a86e", null ],
    [ "energize", "class_d_i_s_t_nx.html#a43b639253b8197f2cdd463cf201850a9", null ],
    [ "getDist", "class_d_i_s_t_nx.html#a58b6ee23939484e8bd014a1c46d4aa7f", null ],
    [ "getType", "class_d_i_s_t_nx.html#a49de7a3c6bca8c4b7293dd12b317b76f", null ],
    [ "getVolt", "class_d_i_s_t_nx.html#a2613101e5ee06ebe0a5996a3dc9fb8d2", null ],
    [ "issueCommand", "class_d_i_s_t_nx.html#a28da968654b957bd464ce10e94e1439a", null ]
];