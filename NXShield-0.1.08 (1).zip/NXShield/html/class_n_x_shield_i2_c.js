var class_n_x_shield_i2_c =
[
    [ "NXShieldI2C", "class_n_x_shield_i2_c.html#a5c1fae53f32f74f4be71df62db1cf886", null ],
    [ "checkAddress", "class_n_x_shield_i2_c.html#ad30026de8614ba2f790f8fd797c25ddf", null ],
    [ "getDeviceID", "class_n_x_shield_i2_c.html#a78fe096e3ec5b68c7b742868435220e7", null ],
    [ "getErrorCode", "class_n_x_shield_i2_c.html#a92f5bed3c99000871f4b59372c1e7ac8", null ],
    [ "getFeatureSet", "class_n_x_shield_i2_c.html#ae6971cd10c7bd6f723128e9492b8a930", null ],
    [ "getFirmwareVersion", "class_n_x_shield_i2_c.html#a45a13410a3b8927101d3c80d29274a3a", null ],
    [ "getVendorID", "class_n_x_shield_i2_c.html#a5b62ccb44c8a420cd97abe6483a6bc46", null ],
    [ "init", "class_n_x_shield_i2_c.html#a6d3596bb2f4c1bf5caf84b667ede2d16", null ],
    [ "readByte", "class_n_x_shield_i2_c.html#a1cff5922dedb607a0b40097b47a66013", null ],
    [ "readInteger", "class_n_x_shield_i2_c.html#adacb4a1e890807e66422f34bae66d37e", null ],
    [ "readLong", "class_n_x_shield_i2_c.html#a70e5b025df3c3cce3630387562c673a3", null ],
    [ "readRegisters", "class_n_x_shield_i2_c.html#a249a7ffd5999ef58dc5cce93fbd283e7", null ],
    [ "readString", "class_n_x_shield_i2_c.html#aee7301002dd530520eca761e5b95749e", null ],
    [ "setAddress", "class_n_x_shield_i2_c.html#a9294ab765c1a18929fefdb9203f943b7", null ],
    [ "writeByte", "class_n_x_shield_i2_c.html#afcaafa0be2e456511f75b18d6068819a", null ],
    [ "writeInteger", "class_n_x_shield_i2_c.html#a75d17fd0355221da0144e8c969fe20bd", null ],
    [ "writeLong", "class_n_x_shield_i2_c.html#ae59a7c2042d15545d13b80b5acc933d3", null ],
    [ "writeRegisters", "class_n_x_shield_i2_c.html#a4715f68719724131fae50cb7bcb9a76b", null ],
    [ "_i2c_buffer", "class_n_x_shield_i2_c.html#adcbb81f50097622ed83729b4be884be6", null ],
    [ "m_protocol", "class_n_x_shield_i2_c.html#ac921b6475cba46d9f3caf06b4e0799f5", null ],
    [ "mp_shield", "class_n_x_shield_i2_c.html#a236bfa5f3b81e24cdb070add8b5f9f61", null ]
];