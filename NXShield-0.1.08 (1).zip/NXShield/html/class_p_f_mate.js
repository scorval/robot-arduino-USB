var class_p_f_mate =
[
    [ "PFMate", "class_p_f_mate.html#a0e68551b9f279980beeacc5dd95b9fce", null ],
    [ "controlMotor", "class_p_f_mate.html#acd0b7f4c2a8ff54e81a8385bbf8be1aa", null ],
    [ "issueCommand", "class_p_f_mate.html#aef274a64833e5764d35413f271cfed06", null ],
    [ "sendSignal", "class_p_f_mate.html#ad2face621fe7ace14d1d84ec720389c6", null ],
    [ "setChannel", "class_p_f_mate.html#ab83f88c974c5c17547f833c4d2f48d6c", null ],
    [ "setControl", "class_p_f_mate.html#aa22cb0cbde3b4ef0e964dd4db9bb26d0", null ],
    [ "setOperationA", "class_p_f_mate.html#aa537ac6d815f2d38b654a87acce01a7a", null ],
    [ "setOperationB", "class_p_f_mate.html#a74e9b61fdba248531394a9add455bfe4", null ],
    [ "setSpeedA", "class_p_f_mate.html#a2746cb371c77124496056ae44c527467", null ],
    [ "setSpeedB", "class_p_f_mate.html#a1bc5fd8826b2a44673bda578f0a3ffe5", null ]
];