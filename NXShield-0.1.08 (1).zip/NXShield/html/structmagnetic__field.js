var structmagnetic__field =
[
    [ "error", "structmagnetic__field.html#a7dce7d4bd0f86ffec29a48e5042599d3", null ],
    [ "mx", "structmagnetic__field.html#abc0e0cdff5c13aec3adbc23486bf1158", null ],
    [ "mx_h", "structmagnetic__field.html#ae8bfcd3b08429b6a95507bbca826e30b", null ],
    [ "mx_l", "structmagnetic__field.html#a92ecd7973d13e1f2b1eb0d14c8270894", null ],
    [ "my", "structmagnetic__field.html#a14c0c7b3f90afceea131bf8fd6b3da2d", null ],
    [ "my_h", "structmagnetic__field.html#ad95e3ce79237e771761c3a99cdd2614e", null ],
    [ "my_l", "structmagnetic__field.html#a68762acf927c8975d1393e69dd0e8245", null ],
    [ "mz", "structmagnetic__field.html#ab5b9860a17bd2160d0edad3c29f50cc5", null ],
    [ "mz_h", "structmagnetic__field.html#a0c1b9c2a008e45ba0b43baa1fad3ce4c", null ],
    [ "mz_l", "structmagnetic__field.html#a3eac4c0eb2b7df43ebcc948dd340d89c", null ]
];