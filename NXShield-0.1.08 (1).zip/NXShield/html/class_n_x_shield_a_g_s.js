var class_n_x_shield_a_g_s =
[
    [ "NXShieldAGS", "class_n_x_shield_a_g_s.html#a6d807991a53c7bafdf2208a6ff3c4648", null ],
    [ "NXShieldAGS", "class_n_x_shield_a_g_s.html#a6bfdccb541e50cee9b5068fd038ddc39", null ],
    [ "init", "class_n_x_shield_a_g_s.html#a9c60989f7c3b5af11a24ecff9c3844de", null ],
    [ "readRaw", "class_n_x_shield_a_g_s.html#aac90743fa5f62d40d4f010ef432bc988", null ],
    [ "setType", "class_n_x_shield_a_g_s.html#a3608222af99dd4ea9cae2fb97c9db613", null ],
    [ "m_bp", "class_n_x_shield_a_g_s.html#a4328ab2b55bb1bc09428017a63cc007c", null ],
    [ "mp_shield", "class_n_x_shield_a_g_s.html#a3dab0e8bc8c18023806ddf1c684c6f1b", null ]
];