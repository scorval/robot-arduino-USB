var class_n_x_shield_bank_b =
[
    [ "NXShieldBankB", "class_n_x_shield_bank_b.html#a2ae25c57963f1314c024a28b78e5e961", null ],
    [ "sensorReadRaw", "class_n_x_shield_bank_b.html#a204318a67d2f45ff1b35bc6a43c47bbf", null ],
    [ "sensorSetType", "class_n_x_shield_bank_b.html#a04c974e54b4f4fded436813938557070", null ]
];