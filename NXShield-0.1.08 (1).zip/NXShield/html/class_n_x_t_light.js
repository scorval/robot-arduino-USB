var class_n_x_t_light =
[
    [ "init", "class_n_x_t_light.html#af554993530d96daddc3e11cdd189e76c", null ],
    [ "setAmbient", "class_n_x_t_light.html#aa7f5b60b7250f5eda99584bf83861ec3", null ],
    [ "setReflected", "class_n_x_t_light.html#afade1ddbede1546b0002829c549be6c8", null ]
];