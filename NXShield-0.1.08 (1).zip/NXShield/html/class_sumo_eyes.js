var class_sumo_eyes =
[
    [ "detectObstacleZone", "class_sumo_eyes.html#a987e86bcc58aaf97b68502a8bd97f61a", null ],
    [ "init", "class_sumo_eyes.html#ad1ff5eba2c174f7ed2e2cf1f0c9e858a", null ],
    [ "OBZoneToString", "class_sumo_eyes.html#a640bb99d6e1739c9cbcda76815dcfb3a", null ],
    [ "setLongRange", "class_sumo_eyes.html#abe1dfc4f1187223aa80c05cac3d60d49", null ],
    [ "setShortRange", "class_sumo_eyes.html#ab239b57cbf6d05b5b14841a51743aef5", null ],
    [ "setType", "class_sumo_eyes.html#a1d188cd70b30133f60e3636bf894015d", null ]
];