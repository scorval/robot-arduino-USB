var class_n_x_t_h_i_d =
[
    [ "NXTHID", "class_n_x_t_h_i_d.html#a45287a9f96e42726fcbd7703d2e1946d", null ],
    [ "asciiMode", "class_n_x_t_h_i_d.html#afc241cbe48d2f4d84dad0e2a3e8b4385", null ],
    [ "directMode", "class_n_x_t_h_i_d.html#aaa26debe6ab6661be97ff0ceebd3607b", null ],
    [ "issueCommand", "class_n_x_t_h_i_d.html#aee6e4a51e754f6eb9976347ae54c3e9f", null ],
    [ "sendKeyboardData", "class_n_x_t_h_i_d.html#ac37b5251f7f9e015509dd2bc8d075927", null ],
    [ "sendTextString", "class_n_x_t_h_i_d.html#ae6e68c3aad02acfb948e8340c309b1e6", null ],
    [ "setModifier", "class_n_x_t_h_i_d.html#ab5ab1786d96ae7d09298fe1a8b3372a3", null ],
    [ "transmitData", "class_n_x_t_h_i_d.html#a721439956bfcc7edb2dc27564984e753", null ]
];