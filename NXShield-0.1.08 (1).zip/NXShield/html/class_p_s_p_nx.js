var class_p_s_p_nx =
[
    [ "PSPNx", "class_p_s_p_nx.html#acc3b4b8d961f0650520350545ce3e396", null ],
    [ "deEnergize", "class_p_s_p_nx.html#ae92b9d5068c662ddbe66c12f86caad92", null ],
    [ "energize", "class_p_s_p_nx.html#af8c421414ab014697996f46386ee5f29", null ],
    [ "getButtons", "class_p_s_p_nx.html#a9cefef390c79df2c6f578735ac00d1dc", null ],
    [ "getXLJoy", "class_p_s_p_nx.html#a4d97e6c49ae84ce7740cce59b1b401e1", null ],
    [ "getXRJoy", "class_p_s_p_nx.html#aed0051dcddda638bd2a290e213ab0465", null ],
    [ "getYLJoy", "class_p_s_p_nx.html#ae87f7099a06240dea3b2cea856751c47", null ],
    [ "getYRJoy", "class_p_s_p_nx.html#abc3ce655b708e680976e3b1491d76791", null ],
    [ "issueCommand", "class_p_s_p_nx.html#a23e1a50c27a0f134c4ecff64800b76df", null ],
    [ "setAnalogMode", "class_p_s_p_nx.html#a8cdea43881a2010f014ead662af95954", null ],
    [ "setDigitalMode", "class_p_s_p_nx.html#ab1a8a39c284634941da4baf852a6711a", null ]
];