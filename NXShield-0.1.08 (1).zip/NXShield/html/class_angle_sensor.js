var class_angle_sensor =
[
    [ "AngleSensor", "class_angle_sensor.html#a10b07440429d7231c6f0935ffd820e39", null ],
    [ "getAngle", "class_angle_sensor.html#a8984e583b4c2209d2db24dd9bac04f08", null ],
    [ "getRawReading", "class_angle_sensor.html#a6cd7f5f99b82141e94f043149ee33a9c", null ],
    [ "issueCommand", "class_angle_sensor.html#af716abfd0db5833c3698a4ac0ee5a7e8", null ],
    [ "reset", "class_angle_sensor.html#a7e03e271ae46b803abd60bf7c36cc721", null ]
];