var class_e_v3_infra_red =
[
    [ "EV3InfraRed", "class_e_v3_infra_red.html#a7cda7570df0b1825899ba2c3af20d874", null ],
    [ "BeaconInRange", "class_e_v3_infra_red.html#a081160d707310e29d7bc510c89b037fa", null ],
    [ "readBeaconHeading", "class_e_v3_infra_red.html#a7a5fa47d1072daca406ba1003185a1d8", null ],
    [ "readBeaconProx", "class_e_v3_infra_red.html#a85ffdb1c1dc4c673ec9f35b4c2d28162", null ],
    [ "readButtonValue", "class_e_v3_infra_red.html#a41855baf1f9816bef9d1295c45222996", null ],
    [ "setMode", "class_e_v3_infra_red.html#adcaf8953b8f5e9aceac70089175e89b8", null ]
];