var class_e_v3_sonar =
[
    [ "EV3Sonar", "class_e_v3_sonar.html#a6b188f6fe3017992aa5d9847973861b0", null ],
    [ "detect", "class_e_v3_sonar.html#a18d5f660f781d9606e196bd74f53b244", null ],
    [ "setMode", "class_e_v3_sonar.html#a35f9edc948dff18e53a44c6e16bab769", null ]
];