var class_e_v3_color =
[
    [ "EV3Color", "class_e_v3_color.html#aa5a86baa19bae0ffd8ef293585a91f9f", null ],
    [ "setMode", "class_e_v3_color.html#a68fe98db20fe7a1ebcd4e06292ae2fb7", null ]
];