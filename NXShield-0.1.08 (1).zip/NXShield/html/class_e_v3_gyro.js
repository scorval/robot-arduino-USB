var class_e_v3_gyro =
[
    [ "EV3Gyro", "class_e_v3_gyro.html#a6590e74367aab584736697266aef229d", null ],
    [ "setMode", "class_e_v3_gyro.html#a8160cc97299499ca28e1bbf9789f4e05", null ]
];