var class_magic_wand =
[
    [ "MagicWand", "class_magic_wand.html#a913ba0f713302327c3755c46b3622484", null ],
    [ "lightWand", "class_magic_wand.html#aa820d585c486ad0279c75009d573055d", null ]
];