var searchData=
[
  ['r',['r',['../structcolor.html#abdd01e7f85b6d9af6f95b50efa25675a',1,'color']]]
];
