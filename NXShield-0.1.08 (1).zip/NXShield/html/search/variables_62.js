var searchData=
[
  ['b',['b',['../structcolor.html#a54c0fe3a59d6f43a47d365c545de1693',1,'color']]],
  ['bank_5fa',['bank_a',['../class_n_x_shield.html#ab1dd9157f2c51c5bb781ed1c43b2a3e2',1,'NXShield']]],
  ['bank_5fb',['bank_b',['../class_n_x_shield.html#a53eeee21082ca678424648a3dd6b53bb',1,'NXShield']]]
];
