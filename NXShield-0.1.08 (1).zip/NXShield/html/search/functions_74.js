var searchData=
[
  ['takesnapshot',['takeSnapshot',['../class_line_leader.html#a2660bc2fd65bdafa015e09252fa28ba0',1,'LineLeader']]],
  ['transmitdata',['transmitData',['../class_n_x_t_h_i_d.html#a721439956bfcc7edb2dc27564984e753',1,'NXTHID']]]
];
