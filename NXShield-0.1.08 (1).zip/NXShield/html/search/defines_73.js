var searchData=
[
  ['sh_5fbank_5fa',['SH_Bank_A',['../_n_x_shield_8h.html#a8ba243786ea3e34a22595e477cfa3c92',1,'NXShield.h']]],
  ['sh_5fbank_5fb',['SH_Bank_B',['../_n_x_shield_8h.html#aa57f621cc96fa9cae39367ab1a161526',1,'NXShield.h']]],
  ['sh_5fs1',['SH_S1',['../_n_x_shield_8h.html#ae4b22cb9a9f5606438028fa56752fc32',1,'NXShield.h']]],
  ['sh_5fs2',['SH_S2',['../_n_x_shield_8h.html#a6fad125ff964ca0354d51e63c4514990',1,'NXShield.h']]],
  ['sh_5ftype_5fanalog',['SH_Type_ANALOG',['../_n_x_shield_8h.html#a7180516dde8808566450257fd4aa5dac',1,'NXShield.h']]],
  ['sh_5ftype_5fanalog_5f9volts',['SH_Type_ANALOG_9VOLTS',['../_n_x_shield_8h.html#abe4a0002cf4e00680d6712e3de9ed4a8',1,'NXShield.h']]],
  ['sh_5ftype_5fanalog_5factive',['SH_Type_ANALOG_ACTIVE',['../_n_x_shield_8h.html#a07e00c4d0ffff0cf884fe0c16e159554',1,'NXShield.h']]],
  ['sh_5ftype_5fanalog_5fpassive',['SH_Type_ANALOG_PASSIVE',['../_n_x_shield_8h.html#a8a70a302dcd0d4ea7489097f69fc3d2f',1,'NXShield.h']]],
  ['sh_5ftype_5fdatabit0_5fhigh',['SH_Type_DATABIT0_HIGH',['../_n_x_shield_8h.html#a7509df67b94f3dcea2f828ce5d20ab6a',1,'NXShield.h']]],
  ['sh_5ftype_5fdatabit1_5fhigh',['SH_Type_DATABIT1_HIGH',['../_n_x_shield_8h.html#a59c5620fcade633460557d078edbf8bb',1,'NXShield.h']]],
  ['sh_5ftype_5fi2c',['SH_Type_I2C',['../_n_x_shield_8h.html#a9edbde546947365012d6d4b439a670e7',1,'NXShield.h']]],
  ['sh_5ftype_5fmixed',['SH_Type_MIXED',['../_n_x_shield_8h.html#a3f5c7741e971a577f01acaa323823c33',1,'NXShield.h']]]
];
