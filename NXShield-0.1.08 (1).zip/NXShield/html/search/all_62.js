var searchData=
[
  ['b',['b',['../structcolor.html#a54c0fe3a59d6f43a47d365c545de1693',1,'color']]],
  ['bank_5fa',['bank_a',['../class_n_x_shield.html#ab1dd9157f2c51c5bb781ed1c43b2a3e2',1,'NXShield']]],
  ['bank_5fb',['bank_b',['../class_n_x_shield.html#a53eeee21082ca678424648a3dd6b53bb',1,'NXShield']]],
  ['basei2cdevice',['BaseI2CDevice',['../class_base_i2_c_device.html',1,'BaseI2CDevice'],['../class_base_i2_c_device.html#a62f63fa5bcbea73b209d44c70ae1def3',1,'BaseI2CDevice::BaseI2CDevice()']]],
  ['beaconinrange',['BeaconInRange',['../class_e_v3_infra_red.html#a081160d707310e29d7bc510c89b037fa',1,'EV3InfraRed']]],
  ['begincompasscalibration',['beginCompassCalibration',['../class_absolute_i_m_u.html#a29a56557a0002475458c1dc422c097bc',1,'AbsoluteIMU']]]
];
