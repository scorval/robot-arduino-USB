var class_n_x_t_servo =
[
    [ "NXTServo", "class_n_x_t_servo.html#aa541269a7a0e3a03b94d42430608f21f", null ],
    [ "editMacro", "class_n_x_t_servo.html#af45ec01a77babd33a4eeb4402fad8394", null ],
    [ "getBatteryVoltage", "class_n_x_t_servo.html#a8e40b8c87b8101ffbc609e765e410348", null ],
    [ "gotoEEPROM", "class_n_x_t_servo.html#aae94f1ab217467c9e04f0f867ef0ba4c", null ],
    [ "haltMacro", "class_n_x_t_servo.html#a3ba0f86e8e647458b9eefa1c906d31f2", null ],
    [ "issueCommand", "class_n_x_t_servo.html#aa0daf0781701ca1488a98343e65d1fb9", null ],
    [ "pauseMacro", "class_n_x_t_servo.html#a513cc2fed96d09fcf6fa1853229ad39e", null ],
    [ "reset", "class_n_x_t_servo.html#a7758b56094d7f8a890695ab8fef995f6", null ],
    [ "resumeMacro", "class_n_x_t_servo.html#a92936728e747345f18d65a9c313aaa58", null ],
    [ "runServo", "class_n_x_t_servo.html#adf8a03ba564b3ce4993fae701a90384b", null ],
    [ "setPosition", "class_n_x_t_servo.html#ab3268d7f243da3c2a46a1c06af506230", null ],
    [ "setSpeed", "class_n_x_t_servo.html#a6abf50ebc71a50e4011744cf803a8ded", null ],
    [ "storeInitial", "class_n_x_t_servo.html#a679ac67e7a61320bd77e9ca9ddcb9010", null ]
];