var class_volt_meter =
[
    [ "VoltMeter", "class_volt_meter.html#a02be89d8e561b199b5d858accfdf8155", null ],
    [ "getAVoltage", "class_volt_meter.html#ac7bf834ef4d70d0eff2150ef96aa7226", null ],
    [ "getReference", "class_volt_meter.html#af7a537ae7e81881a0d19caa666e6c610", null ],
    [ "getRVoltage", "class_volt_meter.html#ad4f1983e3e37d5d249f4c15a36142ef3", null ],
    [ "issueCommand", "class_volt_meter.html#a3c88ddf92a8f29c595d3a2477e6d3681", null ],
    [ "setReferenceV", "class_volt_meter.html#a950b8b9b3bd542d3b17181ed6ed56f77", null ]
];